"use strict";
//---------------------------------------------
var sun = new Image();
var moon = new Image();
var earth = new Image();
var comet, comets = [], CometVar;
var FrameVar;
var ctx;
var backgroundColor = "#CCCCCC";
function init(){
  sun.src = 'https://mdn.mozillademos.org/files/1456/Canvas_sun.png';
  moon.src = 'https://mdn.mozillademos.org/files/1443/Canvas_moon.png';
  earth.src = 'https://mdn.mozillademos.org/files/1429/Canvas_earth.png';
  window.requestAnimationFrame(draw);
}

function draw() {
  ctx = document.getElementById('myCanvas').getContext('2d');

  ctx.globalCompositeOperation = 'destination-over';
  ctx.clearRect(0,0,700,700); // clear canvas

  ctx.fillStyle = 'rgba(0,0,0,0.4)';
  ctx.strokeStyle = 'rgba(0,153,255,0.4)';
  ctx.save();
  ctx.translate(350,350);

  // Planet 
  var time = new Date();
  ctx.rotate( ((2*Math.PI)/60)*time.getSeconds() + ((2*Math.PI)/60000)*time.getMilliseconds() );
  ctx.translate(105,0);
  ctx.fillRect(0,-12,500,24); // Shadow
  ctx.drawImage(earth,-12,-12);

  // Moon
  ctx.save();
  ctx.rotate( ((2*Math.PI)/6)*time.getSeconds() + ((2*Math.PI)/6000)*time.getMilliseconds() );
  ctx.translate(0,28.5);
  ctx.drawImage(moon,-3.5,-3.5);
  ctx.restore();

  ctx.restore();
  

  //Planet 1

  ctx.fillStyle = 'rgba(0,0,0,0.4)';
  ctx.strokeStyle = 'rgba(0,153,255,0.4)';
  ctx.save();
  ctx.translate(350,350);

  var time = new Date();
  var s = time.getSeconds();
  var m = time.getMilliseconds();
  ctx.rotate( ((2*Math.PI)/60/1.7)*time.getSeconds() + ((2*Math.PI)/60000/1.7)*time.getMilliseconds() );
  ctx.translate(155,0);
  ctx.fillRect(0,-12,500,24); // Shadow
  ctx.drawImage(earth,-12,-12);

  ctx.restore();



// Planet 2
  ctx.fillStyle = 'rgba(0,0,0,0.4)';
  ctx.strokeStyle = 'rgba(0,153,255,0.4)';
  ctx.save();
  ctx.translate(350,350);

  var time = new Date();
  ctx.rotate(  ((2*Math.PI)/60/4)*time.getSeconds() + ((2*Math.PI)/60000/4)*time.getMilliseconds() );
  ctx.translate(205,0);
  ctx.fillRect(0,-12,500,24); // Shadow
  ctx.drawImage(earth,-12,-12);

  ctx.restore();



// Planet 3
  ctx.fillStyle = 'rgba(0,0,0,0.4)';
  ctx.strokeStyle = 'rgba(0,153,255,0.4)';
  ctx.save();
  ctx.translate(350,350);

  var time = new Date();
  ctx.rotate(  ((2*Math.PI)/60/6)*time.getSeconds() + ((2*Math.PI)/60000/6)*time.getMilliseconds() );
  ctx.translate(305,0);
  ctx.fillRect(0,-12,500,24); // Shadow
  ctx.drawImage(earth,-12,-12);

  ctx.save();
  ctx.rotate( ((2*Math.PI)/9)*time.getSeconds() + ((2*Math.PI)/9000)*time.getMilliseconds() );
  ctx.translate(0,24.5);
  ctx.drawImage(moon,-3.5,-3.5);

  ctx.restore();
  ctx.restore();


  window.requestAnimationFrame(draw);
}

function Rect( color )
{
    this.X = 0;
    this.Y = 0;
    this.W = 1;
    this.H = 1;
    this.Color = color;
    this.X0 = 0;
    this.Y0 = 0;

    this.display = function( ) { 
      ctx.fillStyle = this.Color;
      ctx.fillRect( this.X, this.Y, this.W, this.H );
    };

    this.setReferencePoint = function( x, y ) {
        this.X0 = x;
        this.Y0 = y;
    }
}

function Comet (rX, rY) {
    this.X = 0;
    this.Y = 0;

    this.display = function () {
        ctx.fillStyle = "#936500";
        ctx.beginPath();
        ctx.rect(this.x -0.5, this.y, 1, 2);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = "#00FF00";
        ctx.beginPath();
        ctx.arc( this.X, this.Y, 1, 0, Math.PI * 2, true );
        ctx.closePath();
        ctx.fill();
    }

    this.setReferencePoint = function( x, y ) {
        this.X0 = x;
        this.Y0 = y;
    }

    this.setScale = function( s ) {
        this.S = s;
    }
}

function nextFrame() {

    ctx = document.getElementById('myCanvas').getContext('2d');
    context.fillStyle = backgroundColor;
    ctx.clearRect( 0, 0, 700, 700 );
//-------------------------------------------------------------------
    for ( let i = 0; i < comets.length; i ++ ) {
        var comet = comets[ i ];
        var cometScale = comet.S;
        if ( cometScale == 1 ) { 
            comet.setReferencePoint( comet.X0 - 2, comet.Y0 );
            ctx.save();
                ctx.transform( 10, 0, 0, 20, comet.X0, comet.Y0 );
                comet.display();
            ctx.restore();
        }
        else 
            if ( cometScale == 2 ) {
                comet.setReferencePoint( comet.X0 - 4, comet.Y0 );
                ctx.save();
                    ctx.transform( 20, 0, 0, 40, comet.X0, comet.Y0 );
                    comet.display();
                ctx.restore();
        }
        else 
            if ( cometScale == 3 ) {
                comet.setReferencePoint( comet.X0 - 6, comet.Y0 );
                ctx.save();
                    ctx.transform( 30, 0, 0, 60, comet.X0, comet.Y0 );
                    comet.display();
                ctx.restore();
            }
        if ( comet.X0 < 0 ) comets.splice( i, 1 );
    }

    FrameVar = setTimeout( nextFrame, 100 );
}

    function nextCometAnimation( ) {
    var isOK = Math.floor( Math.random() * 5 );
    console.log( isOK, comets.length );
    //isOK = 1;
    if ( isOK === 1 ) {
        var cY = Math.floor( Math.random() * ( 700 - 200 ) );
        comet = new Comet(700, cY );
        if ( cY < 700 / 4 ) comet.setScale( 1 );
        else if ( cY < 700 / 2 ) comet.setScale( 2 );
        else comet.setScale( 3 );
        comet.setReferencePoint( 700, cY );
        comets.push( comet );
    }
//-------------------------------------------------------------------
    CometVar = setTimeout( nextCometAnimation, 50 );
}

init();
